package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;


public class BankingDAOServicesImpl implements BankingDAOServices{
	private Customer customerList[]=new Customer[10];
	private int CUSTOMER_IDX_COUNTER=0;
	private int CUSTOMER_ID_COUNTER=111;
	private int ACCOUNT_NUMBER=0000001;
	private int TRANSACTION_ID=001;
	Random rand = new Random();
	public BankingDAOServicesImpl() {
		
	}
	@Override
	public int insertCustomer(Customer customer) {
		for(int i=0;i<customerList.length;i++) {
			if(customerList[i]!=null && CUSTOMER_IDX_COUNTER >=0.7*customerList.length) {
				Customer []temp = new Customer[customerList.length+10];
				System.arraycopy(customerList, 0, temp, 0, customerList.length);
				customerList=temp;
			}
			if(customerList[i]!=null) {
				customerList[CUSTOMER_IDX_COUNTER++]=customer;
				customerList[i].setCustomerId(CUSTOMER_ID_COUNTER++);
				return customerList[i].getCustomerId();
			}
		}
		return 0;
	}

	@Override
	public long insertAccount(int customerId, Account account) {
			for(int i=0;i<this.getCustomer(customerId).getAccounts().length;i++) {
				if(getCustomer(customerId).getAccounts()[i]!=null && customerList[i].getACCOUNT_IDX_COUNTER() >=0.7*getCustomer(customerId).getAccounts().length) {
					Account []temp = new Account[getCustomer(customerId).getAccounts().length+10];
					System.arraycopy(getCustomer(customerId).getAccounts(), 0, temp, 0, getCustomer(customerId).getAccounts().length);
					getCustomer(customerId).setAccounts(temp);
				}
				if(getCustomer(customerId).getAccounts()[i]!=null) {
					getCustomer(customerId).getAccounts()[getCustomer(customerId).getACCOUNT_IDX_COUNTER()]=account;
					getCustomer(customerId).setACCOUNT_IDX_COUNTER(getCustomer(customerId).getACCOUNT_IDX_COUNTER()+1);
					account.setAccountNo(ACCOUNT_NUMBER++);
					return account.getAccountNo();
				}
			}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++) {
			if(getCustomer(customerId).getAccounts()!=null) {
				getCustomer(customerId).getAccounts()[i]=account;
				return true;
			}		
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getAccount(customerId, account.getAccountNo()).setPinNumber(rand.nextInt(10000));
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<getTransactions(customerId, accountNo).length;i++){
			if(getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()>0.7*getTransactions(customerId, accountNo).length){
				Transaction []temp = new Transaction[getTransactions(customerId, accountNo).length+10];
				System.arraycopy(getTransactions(customerId, accountNo), 0, temp, 0, getTransactions(customerId, accountNo).length);
			}
			if(getTransactions(customerId, accountNo)!=null){
				getTransactions(customerId, accountNo)[i]=transaction;
				transaction.setTransactionId(TRANSACTION_ID++);
				getAccount(customerId, accountNo).setTRANSACTION_IDX_COUNTER(getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER());
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				customerList[i]=null;
			int k=i;
			for(int j=k+1;j<customerList.length;j++){
				if(customerList[j]!=null){
					customerList[k]=customerList[j];
				customerList[k]=null;
				k++;
				}
			}
		}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++) {
			if(getCustomer(customerId).getAccounts()[i]!=null&&getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo)
				getCustomer(customerId).getAccounts()[i]=null;
			for(int j=i+1;j<getCustomer(customerId).getAccounts().length;j++) {
				getCustomer(customerId).getAccounts()[i]=getCustomer(customerId).getAccounts()[j];
				getCustomer(customerId).getAccounts()[j]=null;
			}
		}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++) {
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId)
				return customerList[i];
		}
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++) {
			if(getCustomer(customerId).getAccounts()[i]!=null && getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo)
				return getCustomer(customerId).getAccounts()[i];
		}
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		
		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		if(getCustomer(customerId)!=null)
		return getCustomer(customerId).getAccounts();
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		
		return getAccount(customerId, accountNo).getTransactions();
	}

}
