package com.cg.banking.main;

import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass { 
	public static void main(String[] args) {
	BankingServicesImpl bankingservices = new BankingServicesImpl();
	try {
		int i=bankingservices.acceptCustomerDetails("meher", "prasad", "xyz@.com", "123456", "hyd", "ap", 535003, "hyd", "ap", 535002);
		System.out.println(i);
	} catch (BankingServicesDownException e) {
		e.printStackTrace();
	}
	}
}
