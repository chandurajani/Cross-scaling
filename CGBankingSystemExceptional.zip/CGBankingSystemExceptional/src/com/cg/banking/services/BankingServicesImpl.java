package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	private BankingDAOServicesImpl daoservices;
	public BankingServicesImpl() {
		daoservices =new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
	return	daoservices.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
		
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		
		return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		daoservices.getAccount(customerId, accountNo).setAccountBalance(daoservices.getAccount(customerId, accountNo).getAccountBalance()+amount);
		
		return daoservices.getAccount(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
			while(daoservices.getAccount(customerId, accountNo).getPinCounter()>3){
				if(daoservices.getAccount(customerId, accountNo).getPinNumber()==pinNumber){
					daoservices.getAccount(customerId, accountNo).setAccountBalance(daoservices.getAccount(customerId, accountNo).getAccountBalance()-amount);
					return daoservices.getAccount(customerId, accountNo).getAccountBalance();
				}
				daoservices.getAccount(customerId, accountNo).setPinCounter(daoservices.getAccount(customerId, accountNo).getPinCounter()+1);
				System.out.println("Wrong pin");
			}
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		while(daoservices.getAccount(customerIdFrom, accountNoFrom).getPinCounter()>3){
			if(accountNoTo==accountNoFrom){
				System.out.println("cannot transfer between same accounts");
			}
			else{
			this.withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
			this.depositAmount(customerIdTo, accountNoTo, transferAmount);
			return true;
			}
			daoservices.getAccount(customerIdFrom, accountNoFrom).setPinCounter(daoservices.getAccount(customerIdFrom, accountNoFrom).getPinCounter()+1);
			System.out.println("Account blocked");
		}
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		return daoservices.getAccount(customerId,accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		
		return daoservices.generatePin(customerId, daoservices.getAccount(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		while(getAccountDetails(customerId, accountNo).getPinCounter()<3){
			if(getAccountDetails(customerId, accountNo).getPinCounter()==oldPinNumber){
				getAccountDetails(customerId, accountNo).setPinCounter(newPinNumber);
				return true;
			}
			else{
				System.out.println("invalid pin");
			}
			getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			System.out.println("Account Blocked");
		}
		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() throws BankingServicesDownException {
		
		return daoservices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		return daoservices.getCustomer(customerId).getAccounts();
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return daoservices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		return getAccountDetails(customerId, accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return daoservices.deleteAccount(customerId, accountNo);
	}

}
