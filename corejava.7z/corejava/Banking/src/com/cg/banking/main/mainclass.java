package com.cg.banking.main;

import com.cg.banking.beans.Transaction;

public class mainclass {

	public static void main(String[] args) {
		Transaction transaction1=new Transaction("4567","03:13","savingsaccount","talwade","withdrawl","yes",4500);
		System.out.print(transaction1.getTransactionStatus());
	}
}