package com.cg.Banking.Main;

import com.cg.Payroll.bean.Associate;
import com.cg.Payroll.bean.Salary;

public class MainClass {
	public static void main(String [] str){
	Associate associate= searchassociate("rag");
	if(associate!=null){
		System.out.println(associate.getFirstName());
		System.out.print(associate.getSalary().getBasicSalary());
	}
	else
	System.out.print("no details found");
	}
public static Associate searchassociate(String firstName){
	Associate[] associates=new Associate[4];
	associates[0]=new Associate(1232, 50000, "rag", "raghavendra", "ece", "SA", "BFMPT6248B", "SAI19.TALLAPALLI@GMAIL.COM",new Salary(20000f,2311f,4454f,5454f,7878f,9898f,5465f,6589f,7895f,3256f,54548f));
	associates[1]=new Associate(1234, 10000, "rajani", "chandu", "ece", "SA", "BFMPT62544", "rajanichandu1995@GMAIL.COM",new Salary(21000f,2321f,4464f,5474f,7978f,9198f,5265f,6759f,7595f,3264f,54538f));
	associates[2]=new Associate(1236, 20000, "sai", "raghavendra", "ece", "SA", "BFMPT6248B", "SAI19.TALLAPALLI@GMAIL.COM",new Salary(22000f,2111f,4444f,5404f,7888f,9888f,5415f,6549f,7875f,3246f,54549f));
	associates[3]=new Associate(1237, 25000, "sai", "raghavendra", "ece", "SA", "BFMPT6248B", "SAI19.TALLAPALLI@GMAIL.COM",new Salary(23000f,2321f,4414f,5414f,7870f,9890f,5461f,6588f,7896f,3255f,54448f));
	
	for(Associate associate1 : associates){
		if(associate1 != null && associate1.getYearlyInvestmentunder80c()>=5000 && associate1.getFirstName()==firstName)
		return associate1;
		
	}
	return null;
	 
}    	
}			
