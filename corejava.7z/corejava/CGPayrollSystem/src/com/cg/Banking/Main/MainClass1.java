package com.cg.Banking.Main;

public class MainClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
