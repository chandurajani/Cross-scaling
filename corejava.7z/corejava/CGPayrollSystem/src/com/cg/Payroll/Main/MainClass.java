package com.cg.Payroll.Main;

import com.cg.Payroll.bean.Associate;
import com.cg.Payroll.bean.BankDetails;
import com.cg.Payroll.bean.Salary;

public class MainClass {

	public static void main(String[] args) { 
		BankDetails bankdetails1=new BankDetails(1212,"scb","scbl201711");
		bankdetails1.setAccountNumber(2345);
		System.out.print(bankdetails1.getAccountNumber());
	}
		
}
