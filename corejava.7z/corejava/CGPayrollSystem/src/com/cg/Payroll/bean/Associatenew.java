package com.cg.Payroll.bean;

public class Associatenew {
	

}
