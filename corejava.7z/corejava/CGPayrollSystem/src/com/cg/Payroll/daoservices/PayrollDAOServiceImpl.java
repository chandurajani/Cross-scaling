package com.cg.Payroll.daoservices;

public class PayrollDAOServiceImpl {

}
