package com.cg.Payroll.daoservices;

import com.cg.Payroll.bean.Associate;

public class PayrollDAOServicesImpl {
	private static Associate[] associatelist=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	
	int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associatelist[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}

	boolean updateAssocaite(Associate associate){
		return true;
	}
	boolean deleteAssociate(int associateid){
		return false;
	}
	Associate getAssociate(int associateId){
		return null;
	}
	Associate[] getAssociate(){
		return null;
	}

}
