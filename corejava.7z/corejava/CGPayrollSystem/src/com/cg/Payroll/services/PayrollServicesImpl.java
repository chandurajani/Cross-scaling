package com.cg.Payroll.services;

import com.cg.Payroll.bean.Associate;

public class PayrollServicesImpl {
	public int acceptAssociateDetails(String firstName,String lastName,
	String emailID,String department,String designation,String pancard,
	int yearlyInvestmentUnder80C,int basicSalary,int epf,int comapanyPF,int accountNo,
	String bankName,String ifscCode){
		return 0;
	}
	public int caluculateNetSalary(int associateId){
	return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return null;
	}
	public Associate[] getAllAssociateDetails(){
		return null;
	}

}
