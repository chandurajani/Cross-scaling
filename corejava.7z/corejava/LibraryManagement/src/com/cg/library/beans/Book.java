package com.cg.library.beans;

public class Book {
	private String typeofbook,bookname;
private int bookid,bookavailability,totnoofbooks,noofbooksavailable,noofbooksissued;
public Book(){}
public Book(String typeofbook,String bookname, int bookavailability, int bookid, int totnoofbooks,
		int noofbooksavailable, int noofbooksissued) {
	super();
	this.typeofbook = typeofbook;
	this.bookname = bookname;
	this.bookid = bookid;
	this.bookavailability = bookavailability;
	this.totnoofbooks = totnoofbooks;
	this.noofbooksavailable = noofbooksavailable;
	this.noofbooksissued = noofbooksissued;
}
public String getTypeofbook() {
	return typeofbook;
}
public void setTypeofbook(String typeofbook) {
	this.typeofbook = typeofbook;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public int getBookavailability() {
	return bookavailability;
}
public void setBookavailability(int bookavailability) {
	this.bookavailability = bookavailability;
}
public int getTotnoofbooks() {
	return totnoofbooks;
}
public void setTotnoofbooks(int totnoofbooks) {
	this.totnoofbooks = totnoofbooks;
}
public int getNoofbooksavailable() {
	return noofbooksavailable;
}
public void setNoofbooksavailable(int noofbooksavailable) {
	this.noofbooksavailable = noofbooksavailable;
}
public int getNoofbooksissued() {
	return noofbooksissued;
}
public void setNoofbooksissued(int noofbooksissued) {
	this.noofbooksissued = noofbooksissued;
}
	
}
	