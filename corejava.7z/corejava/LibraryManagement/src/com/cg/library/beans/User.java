package com.cg.library.beans;

public class User {
	private String name;
	private long mobileno;
	private int usedid;
	public User(){}
	public User(String name, int usedid, long mobileno,) {
		super();
		this.name = name;
		this.mobileno = mobileno;
		this.usedid = usedid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	public int getUsedid() {
		return usedid;
	}
	public void setUsedid(int usedid) {
		this.usedid = usedid;
	}
	

}
