package com.cg.static1.main;

import com.example.Class.exaclass;

public class MainClass {

	public static void main(String[] args) {
		exaclass exaclass1=new exaclass();
			System.out.println(exaclass1.s);

	}

}
