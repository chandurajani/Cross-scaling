package com.example.Class;

public class exaclass {
	public static int s=10;
	private int a=2,b=3,c=4;
	public exaclass(){
		s++;
	}
	public exaclass(int a,int b,int c){
		this();
		this.a=a;
		this.b=b;
		this.c=c;
		
	}
	public static int getS() {
		return s;
	}
	public static void setS(int s) {
		exaclass.s = s;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getC() {
		return c;
	}
	public void setC(int c) {
		this.c = c;
	}
	

}
