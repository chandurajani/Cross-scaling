package com.cg.mobilebilling.beans;

public class Customer {
	private String customerId,firstName,lastName,emailId,dateOfBirth,pancardNo;
	private long adharNo,mobileNo;
	private PostPaidAccount[] PostPaidAccounts;
	private Address address;
	public Customer(){}
	public Customer(String customerId, String firstName, String lastName, String emailId,
			String dateOfBirth, String pancardNo,long mobileNo, long adharNo, PostPaidAccount[] postPaidAccounts, Address address) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.pancardNo = pancardNo;
		this.adharNo = adharNo;
		PostPaidAccounts = postPaidAccounts;
		this.address = address;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long  mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	public PostPaidAccount[] getPostPaidAccounts() {
		return PostPaidAccounts;
	}
	public void setPostPaidAccounts(PostPaidAccount[] postPaidAccounts) {
		PostPaidAccounts = postPaidAccounts;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}	