package com.cg.mobilebilling.main;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostPaidAccount;

public class MainClass {

	public static void main(String[] args) {
		
		Customer customer=new Customer("1234","sai","raghu","abc@abc.com","16-07-97","hsa878",8787778787l,5699797975645l,new PostPaidAccount[3],new Address("HYD", "TG", "INDIA", 500001l));
		PostPaidAccount[] postPaidAccounts=customer.getPostPaidAccounts();
		postPaidAccounts[0]=new PostPaidAccount(1111111l, new Plan(), new Bill[3]);
		Bill[] bills=customer.getPostPaidAccounts()[0].getBills();
		bills[0]=new Bill(1, 20, 30, 23, 44, 2, 1, 12, 12, 12, 2000, 500, 2, 3);
		System.out.println(customer.getCustomerId()+" "+customer.getAddress().getCity()+" "+customer.getPostPaidAccounts()[0].getBills()[0].getBillID());
	}	
}
